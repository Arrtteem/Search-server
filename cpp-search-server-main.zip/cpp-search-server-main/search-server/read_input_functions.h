#pragma once

std::string ReadLine();

int ReadLineWithNumber();